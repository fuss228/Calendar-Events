"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CalendarEventsPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian5 = require("obsidian");

// src/storage.ts
var import_obsidian = require("obsidian");

// src/types/model.ts
var DATA_FILE = "calendar-data.json";
function emptyDay() {
  return { events: [], checklist: [], notes: [] };
}
var DEFAULT_CATEGORIES = [
  { id: "email", label: "Email", color: "#3a7bd5" },
  { id: "meeting", label: "Meeting", color: "#7e57c2" },
  { id: "task", label: "Task", color: "#26a69a" },
  { id: "reminder", label: "Reminder", color: "#ef6c00" },
  { id: "personal", label: "Personal", color: "#ec407a" }
];

// src/storage.ts
var CalendarStorage = class {
  constructor(plugin) {
    this.saveTimer = null;
    this.plugin = plugin;
    this.app = plugin.app;
    this.data = this.makeDefault();
  }
  makeDefault() {
    return {
      version: 1,
      categories: DEFAULT_CATEGORIES.slice(),
      days: {}
    };
  }
  async load() {
    const path = (0, import_obsidian.normalizePath)(DATA_FILE);
    const adapter = this.app.vault.adapter;
    if (!await adapter.exists(path)) {
      this.data = this.makeDefault();
      await this.saveNow();
      return;
    }
    try {
      const raw = await adapter.read(path);
      const parsed = JSON.parse(raw);
      const fallback = this.makeDefault();
      this.data = {
        version: 1,
        categories: Array.isArray(parsed.categories) && parsed.categories.length > 0 ? parsed.categories : fallback.categories,
        days: parsed.days && typeof parsed.days === "object" ? parsed.days : {}
      };
    } catch (e) {
      console.error("[CalendarEvents] failed to parse data file, resetting", e);
      this.data = this.makeDefault();
      await this.saveNow();
    }
  }
  getDay(dateKey) {
    return this.data.days[dateKey] ?? emptyDay();
  }
  /** Replace the day entirely. */
  setDay(dateKey, day) {
    const cleaned = {
      events: Array.isArray(day.events) ? day.events : [],
      checklist: Array.isArray(day.checklist) ? day.checklist : [],
      notes: Array.isArray(day.notes) ? day.notes : []
    };
    if (cleaned.events.length === 0 && cleaned.checklist.length === 0 && cleaned.notes.length === 0) {
      delete this.data.days[dateKey];
    } else {
      this.data.days[dateKey] = cleaned;
    }
    this.scheduleSave();
  }
  /** Search vault notes by file name / path. Lightweight, synchronous metadata walk. */
  searchNotes(query, limit = 8) {
    const q = query.trim().toLowerCase();
    const all = [];
    const files = this.app.vault.getMarkdownFiles();
    for (const f of files) {
      all.push({ path: f.path, title: f.basename });
    }
    if (!q)
      return all.slice(0, limit);
    const filtered = all.filter(
      (n) => n.title.toLowerCase().includes(q) || n.path.toLowerCase().includes(q)
    );
    return filtered.slice(0, limit);
  }
  /** Open a vault note or external URL associated with a date. */
  openNoteRef(ref) {
    if (ref.path) {
      const f = this.app.vault.getAbstractFileByPath(ref.path);
      if (f && "name" in f) {
        this.app.workspace.openLinkText(ref.path, "/", false);
      } else {
        this.app.workspace.openLinkText(ref.title, "/", false);
      }
      return;
    }
    if (ref.url) {
      window.open(ref.url, "_blank", "noopener,noreferrer");
    }
  }
  getCategories() {
    return this.data.categories;
  }
  setCategories(cats) {
    this.data.categories = cats;
    this.scheduleSave();
  }
  getAll() {
    return this.data;
  }
  setAll(next) {
    this.data = next;
    this.scheduleSave();
  }
  scheduleSave() {
    if (this.saveTimer !== null) {
      window.clearTimeout(this.saveTimer);
    }
    this.saveTimer = window.setTimeout(() => {
      void this.saveNow();
    }, 200);
  }
  async saveNow() {
    const path = (0, import_obsidian.normalizePath)(DATA_FILE);
    await this.app.vault.adapter.write(path, JSON.stringify(this.data, null, 2));
  }
};
function makeId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

// src/views/CalendarView.ts
var import_obsidian3 = require("obsidian");

// src/modals/DayEditorModal.ts
var import_obsidian2 = require("obsidian");
var DayEditorModal = class extends import_obsidian2.Modal {
  constructor(app, plugin, dateKey) {
    super(app);
    this.plugin = plugin;
    this.dateKey = dateKey;
    this.data = clone(plugin.storage.getDay(dateKey));
  }
  onOpen() {
    const { contentEl, titleEl } = this;
    titleEl.empty();
    this.t = this.plugin.strings();
    titleEl.setText(`${this.t.modalTitlePrefix}${formatPretty(this.dateKey, this.plugin.currentLocale())}`);
    const root = contentEl.createDiv({ cls: "cev-modal-root" });
    this.summaryEl = root.createDiv({ cls: "cev-summary" });
    this.renderSummary();
    const grid = root.createDiv({ cls: "cev-modal-grid" });
    const eventsCol = grid.createDiv({ cls: "cev-col cev-col-events" });
    eventsCol.createEl("h3", { text: this.t.eventsHeading });
    this.eventsContainer = eventsCol.createDiv({ cls: "cev-list" });
    new import_obsidian2.Setting(eventsCol).setName(this.t.addEventLabel).addButton(
      (btn) => btn.setButtonText(this.t.addEventButton).onClick(() => {
        const firstCat = this.plugin.storage.getCategories()[0]?.id ?? "task";
        this.data.events.push({
          id: makeId("ev"),
          title: "",
          type: firstCat
        });
        this.renderEvents();
        this.renderSummary();
      })
    );
    const checkCol = grid.createDiv({ cls: "cev-col cev-col-checklist" });
    checkCol.createEl("h3", { text: this.t.checklistHeading });
    this.checklistContainer = checkCol.createDiv({ cls: "cev-checklist" });
    checkCol.createEl("h3", { text: this.t.notesHeading });
    this.notesContainer = checkCol.createDiv({ cls: "cev-notes" });
    const noteSearch = new NoteSuggest(this.app, this, (note) => {
      const exists = this.data.notes.some(
        (n) => n.path === note.path
      );
      if (!exists) {
        this.data.notes.push({
          id: makeId("note"),
          title: note.title,
          path: note.path,
          url: null
        });
        this.renderNotes();
        this.renderSummary();
      }
    });
    const noteUrlText = "";
    const addUrl = (txt) => {
      const t2 = txt.trim();
      if (!t2)
        return;
      let parsed = null;
      try {
        parsed = new URL(t2);
      } catch (_) {
        parsed = null;
      }
      if (!parsed || !/^https?:/.test(parsed.protocol)) {
        new import_obsidian2.Notice(this.t.invalidUrl);
        return;
      }
      this.data.notes.push({
        id: makeId("note"),
        title: parsed.hostname + parsed.pathname,
        path: null,
        url: parsed.toString()
      });
      this.renderNotes();
      this.renderSummary();
    };
    new import_obsidian2.Setting(checkCol).setName(this.t.notesSearchLabel).setDesc(this.t.notesSearchDesc).addButton(
      (btn) => btn.setButtonText(this.t.notesAddByUrl).onClick(() => {
        const input = prompt(this.t.notesUrlPrompt, "https://");
        if (input != null)
          addUrl(input);
      })
    );
    let newCheckText = "";
    new import_obsidian2.Setting(checkCol).setName(this.t.addChecklistLabel).addText((txt) => {
      txt.setPlaceholder(this.t.addChecklistPlaceholder);
      txt.onChange((v) => newCheckText = v);
      txt.inputEl.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter") {
          ev.preventDefault();
          this.addChecklist(newCheckText);
          newCheckText = "";
          txt.setValue("");
        }
      });
    }).addButton(
      (btn) => btn.setButtonText(this.t.addChecklistButton).onClick(() => {
        this.addChecklist(newCheckText);
        newCheckText = "";
      })
    );
    this.renderEvents();
    this.renderChecklist();
    this.renderNotes();
    const buttons = root.createDiv({ cls: "cev-modal-buttons" });
    buttons.createEl("button", { text: this.t.clearDay, cls: "cev-btn-warn" }, (el) => {
      el.addEventListener("click", () => {
        if (confirm(this.t.confirmClear)) {
          this.data.events = [];
          this.data.checklist = [];
          this.renderEvents();
          this.renderChecklist();
          this.renderSummary();
        }
      });
    });
    buttons.createEl("button", { text: this.t.cancel, cls: "cev-btn" }, (el) => {
      el.addEventListener("click", () => this.close());
    });
    buttons.createEl("button", { text: this.t.save, cls: "cev-btn cev-btn-primary" }, (el) => {
      el.addEventListener("click", () => {
        this.data.events = this.data.events.filter((e) => e.title.trim().length > 0);
        this.plugin.storage.setDay(this.dateKey, this.data);
        new import_obsidian2.Notice(this.t.savedNotice(this.data.events.length, this.data.checklist.length, formatPretty(this.dateKey, this.plugin.currentLocale())));
        this.close();
        this.dispatchRefresh();
      });
    });
  }
  onClose() {
    this.contentEl.empty();
    this.dispatchRefresh();
  }
  dispatchRefresh() {
    window.dispatchEvent(new CustomEvent("calendar-events:updated"));
  }
  addChecklist(text) {
    const trimmed = text.trim();
    if (!trimmed)
      return;
    this.data.checklist.push({ id: makeId("chk"), text: trimmed, done: false });
    this.renderChecklist();
    this.renderSummary();
  }
  renderSummary() {
    const open = this.data.checklist.filter((c) => !c.done).length;
    this.summaryEl.empty();
    this.summaryEl.createSpan({ text: `${this.t.eventCount(this.data.events.length)}, ${this.t.checklistCount(open, this.data.checklist.length)}.` });
  }
  renderEvents() {
    this.eventsContainer.empty();
    if (this.data.events.length === 0) {
      this.eventsContainer.createDiv({ cls: "cev-empty", text: this.t.noEvents });
      return;
    }
    const cats = this.plugin.storage.getCategories();
    this.data.events.forEach((ev, idx) => {
      const row = this.eventsContainer.createDiv({ cls: "cev-event-row" });
      row.style.borderLeftColor = colorOf(ev.type, this.plugin);
      const swatch = row.createDiv({ cls: "cev-event-swatch" });
      swatch.style.backgroundColor = colorOf(ev.type, this.plugin);
      swatch.title = "Event category color";
      const catSelect = row.createEl("select", { cls: "cev-event-category" });
      for (const cat of cats) {
        const opt = catSelect.createEl("option", { text: cat.label, value: cat.id });
        if (cat.id === ev.type)
          opt.selected = true;
        opt.style.color = cat.color;
      }
      catSelect.addEventListener("change", () => {
        ev.type = catSelect.value;
        swatch.style.backgroundColor = colorOf(ev.type, this.plugin);
        row.style.borderLeftColor = colorOf(ev.type, this.plugin);
      });
      const titleInput = row.createEl("input", {
        type: "text",
        cls: "cev-event-title",
        value: ev.title,
        placeholder: this.t.title
      });
      titleInput.value = ev.title;
      titleInput.addEventListener("input", () => {
        ev.title = titleInput.value;
      });
      const timeInput = row.createEl("input", {
        type: "time",
        cls: "cev-event-time",
        value: ev.time ?? ""
      });
      timeInput.value = ev.time ?? "";
      timeInput.addEventListener("input", () => {
        ev.time = timeInput.value;
      });
      const noteInput = row.createEl("input", {
        type: "text",
        cls: "cev-event-note",
        value: ev.note ?? "",
        placeholder: this.t.note
      });
      noteInput.value = ev.note ?? "";
      noteInput.addEventListener("input", () => {
        ev.note = noteInput.value;
      });
      const removeBtn = row.createEl("button", { cls: "cev-event-remove", text: "\u2715" });
      removeBtn.title = this.t.remove;
      removeBtn.addEventListener("click", () => {
        this.data.events.splice(idx, 1);
        this.renderEvents();
        this.renderSummary();
      });
    });
  }
  renderChecklist() {
    this.checklistContainer.empty();
    if (this.data.checklist.length === 0) {
      this.checklistContainer.createDiv({ cls: "cev-empty", text: this.t.noChecklist });
      return;
    }
    this.data.checklist.forEach((item, idx) => {
      const row = this.checklistContainer.createDiv({ cls: "cev-check-row" });
      const cb = row.createEl("input", { type: "checkbox" });
      cb.checked = item.done;
      const text = row.createEl("input", {
        type: "text",
        cls: "cev-check-text",
        value: item.text
      });
      text.value = item.text;
      if (item.done)
        text.addClass("cev-check-done");
      cb.addEventListener("change", () => {
        item.done = cb.checked;
        text.toggleClass("cev-check-done", item.done);
        this.renderSummary();
      });
      text.addEventListener("input", () => {
        item.text = text.value;
      });
      const removeBtn = row.createEl("button", { cls: "cev-event-remove", text: "\u2715" });
      removeBtn.title = this.t.remove;
      removeBtn.addEventListener("click", () => {
        this.data.checklist.splice(idx, 1);
        this.renderChecklist();
        this.renderSummary();
      });
    });
  }
  /** Public accessor used by the inline NoteSuggest helper class. */
  strings() {
    return this.t;
  }
  renderNotes() {
    this.notesContainer.empty();
    if (this.data.notes.length === 0) {
      this.notesContainer.createDiv({
        cls: "cev-empty",
        text: this.t.noNotes
      });
      return;
    }
    this.data.notes.forEach((n, idx) => {
      const row = this.notesContainer.createDiv({ cls: "cev-note-row" });
      const icon = row.createSpan({ cls: "cev-note-icon" });
      icon.setText(n.path ? "\u{1F4C4}" : "\u{1F517}");
      const label = row.createEl("a", {
        cls: "cev-note-label internal-link",
        text: n.title,
        href: "#"
      });
      label.addEventListener("click", (ev) => {
        ev.preventDefault();
        try {
          this.plugin.storage.openNoteRef({ path: n.path, url: n.url, title: n.title });
        } catch (e) {
          new import_obsidian2.Notice(`Failed to open: ${e.message}`);
        }
      });
      const openBtn = row.createEl("button", { cls: "cev-note-open", text: "\u2197" });
      openBtn.title = n.path ? this.t.openNote : this.t.openExternal;
      openBtn.addEventListener("click", () => {
        this.plugin.storage.openNoteRef({ path: n.path, url: n.url, title: n.title });
      });
      const removeBtn = row.createEl("button", { text: "\u2715", cls: "cev-event-remove" });
      removeBtn.title = this.t.remove;
      removeBtn.addEventListener("click", () => {
        this.data.notes.splice(idx, 1);
        this.renderNotes();
        this.renderSummary();
      });
    });
  }
};
function clone(d) {
  return {
    events: d.events.map((e) => ({ ...e })),
    checklist: d.checklist.map((c) => ({ ...c })),
    notes: (d.notes ?? []).map((n) => ({ ...n }))
  };
}
function colorOf(typeId, plugin) {
  const cat = plugin.getCategory(typeId);
  return cat?.color ?? "#888";
}
function formatPretty(key, loc) {
  const [y, m, d] = key.split("-").map((s) => parseInt(s, 10));
  if (!y || !m || !d)
    return key;
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString(
    loc === "zh" ? "zh-CN" : "en-US",
    { weekday: "short", year: "numeric", month: "long", day: "numeric" }
  );
}
var NoteSuggest = class extends import_obsidian2.AbstractInputSuggest {
  constructor(app, modal, onChoose) {
    const inputEl = modal.contentEl.createEl("input", {
      type: "text",
      placeholder: modal.strings().notesSearchPlaceholder,
      cls: "cev-note-search-input"
    });
    super(app, inputEl);
    this.modal = modal;
    this.onChoose = onChoose;
    this.onSelect((value) => {
      this.onChoose(value);
      inputEl.value = "";
    });
  }
  getSuggestions(query) {
    return this.modal.plugin.storage.searchNotes(query, 12);
  }
  renderSuggestion(item, el) {
    el.createDiv({ cls: "cev-note-suggest-title", text: item.title });
    if (item.path !== item.title) {
      el.createDiv({ cls: "cev-note-suggest-path", text: item.path });
    }
  }
};

// src/views/CalendarView.ts
var VIEW_TYPE_CALENDAR = "calendar-events-view";
var CalendarView = class extends import_obsidian3.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.cursor = /* @__PURE__ */ new Date();
    this.refreshTimer = null;
    this.mounted = false;
    this.plugin = plugin;
  }
  getViewType() {
    return VIEW_TYPE_CALENDAR;
  }
  getDisplayText() {
    return "Calendar Events";
  }
  getIcon() {
    return "calendar-with-checkmark";
  }
  async onOpen() {
    const root = this.containerEl.children[1];
    root.empty();
    root.addClass("cev-root");
    const t2 = this.plugin.strings();
    const header = root.createDiv({ cls: "cev-header" });
    const nav = header.createDiv({ cls: "cev-nav" });
    nav.createEl("button", { text: "\u25C0", cls: "cev-nav-btn" }, (el) => {
      el.addEventListener("click", () => this.shiftMonth(-1));
    });
    nav.createEl("button", { text: t2.monthToday, cls: "cev-today-btn" }, (el) => {
      el.addEventListener("click", () => {
        this.cursor = /* @__PURE__ */ new Date();
        this.render();
      });
    });
    nav.createEl("button", { text: "\u25B6", cls: "cev-nav-btn" }, (el) => {
      el.addEventListener("click", () => this.shiftMonth(1));
    });
    this.monthLabelEl = header.createDiv({ cls: "cev-month-label" });
    const weekdays = root.createDiv({ cls: "cev-weekdays" });
    const startMonday = this.plugin.settings.startWeekOnMonday;
    const labels = startMonday ? t2.weekdaysStartMon : t2.weekdays;
    for (const lbl of labels) {
      weekdays.createDiv({ cls: "cev-weekday", text: lbl });
    }
    this.gridEl = root.createDiv({ cls: "cev-grid" });
    this.legendEl = root.createDiv({ cls: "cev-legend" });
    this.mounted = true;
    this.render();
  }
  async onClose() {
    this.mounted = false;
    if (this.refreshTimer !== null) {
      window.clearTimeout(this.refreshTimer);
      this.refreshTimer = null;
    }
  }
  /** Public API: refresh the grid when underlying data changes. */
  requestRender() {
    if (this.mounted)
      this.render();
  }
  shiftMonth(delta) {
    const d = new Date(this.cursor);
    d.setDate(1);
    d.setMonth(d.getMonth() + delta);
    this.cursor = d;
    this.render();
  }
  focusDate(key) {
    const [y, m] = key.split("-").map((s) => parseInt(s, 10));
    if (!y || !m)
      return;
    this.cursor = new Date(y, m - 1, 1);
    this.render();
  }
  render() {
    if (!this.mounted)
      return;
    const t2 = this.plugin.strings();
    this.monthLabelEl.setText(this.formatMonthLabel(this.cursor));
    this.gridEl.empty();
    const cells = this.buildCells(this.cursor, this.plugin.settings.startWeekOnMonday);
    const todayKey = this.plugin.todayKey();
    for (const cell of cells) {
      const dayEl = this.gridEl.createDiv({ cls: "cev-cell" });
      if (!cell.inMonth)
        dayEl.addClass("cev-cell-out");
      if (cell.key === todayKey)
        dayEl.addClass("cev-cell-today");
      const numRow = dayEl.createDiv({ cls: "cev-cell-num" });
      numRow.setText(cell.day !== null ? String(cell.day) : "");
      if (cell.key) {
        const data = this.plugin.storage.getDay(cell.key);
        const dots = dayEl.createDiv({ cls: "cev-cell-dots" });
        const seen = /* @__PURE__ */ new Set();
        for (const ev of data.events) {
          if (seen.size >= 5)
            break;
          if (seen.has(ev.type))
            continue;
          seen.add(ev.type);
          const cat = this.plugin.getCategory(ev.type);
          const dot = dots.createDiv({ cls: "cev-dot" });
          dot.style.backgroundColor = cat?.color ?? "#888";
        }
        if (data.events.length > 5) {
          dots.createDiv({ cls: "cev-dot cev-dot-more", text: `+${data.events.length - 5}` });
        }
        if (data.checklist.length > 0) {
          const remaining = data.checklist.filter((c) => !c.done).length;
          const badge = dayEl.createDiv({ cls: "cev-check-badge" });
          badge.setText(`${data.checklist.length - remaining}/${data.checklist.length}`);
          badge.title = `${remaining} open / ${data.checklist.length} total`;
        }
        if (data.notes && data.notes.length > 0) {
          const link = dayEl.createDiv({ cls: "cev-note-badge" });
          link.setText(`\u{1F517}${data.notes.length}`);
          link.title = `${data.notes.length} linked note(s)`;
          link.addEventListener("click", (ev) => {
            ev.stopPropagation();
            this.plugin.storage.openNoteRef(data.notes[0]);
          });
        }
        dayEl.addEventListener("click", () => {
          new DayEditorModal(this.plugin.app, this.plugin, cell.key).open();
        });
      }
    }
    this.renderLegend();
    if (this.refreshTimer !== null)
      window.clearTimeout(this.refreshTimer);
    this.refreshTimer = window.setTimeout(() => this.render(), 6e4);
  }
  renderLegend() {
    this.legendEl.empty();
    const t2 = this.plugin.strings();
    this.legendEl.createSpan({ text: t2.legend, cls: "cev-legend-title" });
    for (const cat of this.plugin.storage.getCategories()) {
      const chip = this.legendEl.createSpan({ cls: "cev-chip" });
      const swatch = chip.createSpan({ cls: "cev-chip-swatch" });
      swatch.style.backgroundColor = cat.color;
      chip.createSpan({ text: cat.label });
    }
  }
  buildCells(month, startMonday) {
    const year = month.getFullYear();
    const monthIdx = month.getMonth();
    const firstOfMonth = new Date(year, monthIdx, 1);
    const firstWeekday = firstOfMonth.getDay();
    const leading = startMonday ? firstWeekday === 0 ? 6 : firstWeekday - 1 : firstWeekday;
    const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
    const prevMonthLast = new Date(year, monthIdx, 0).getDate();
    const cells = [];
    for (let i = leading - 1; i >= 0; i--) {
      const day = prevMonthLast - i;
      const date = new Date(year, monthIdx - 1, day);
      cells.push({
        key: this.plugin.formatDateKey(date),
        day,
        inMonth: false
      });
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, monthIdx, d);
      cells.push({
        key: this.plugin.formatDateKey(date),
        day: d,
        inMonth: true
      });
    }
    while (cells.length < 42) {
      const idx = cells.length - (leading + daysInMonth);
      const date = new Date(year, monthIdx + 1, idx + 1);
      cells.push({
        key: this.plugin.formatDateKey(date),
        day: idx + 1,
        inMonth: false
      });
    }
    return cells;
  }
  formatMonthLabel(d) {
    return d.toLocaleString(void 0, { year: "numeric", month: "long" });
  }
};

// src/SettingsTab.ts
var import_obsidian4 = require("obsidian");
var PRESET_COLORS = [
  "#e91e63",
  "#9c27b0",
  "#3f51b5",
  "#03a9f4",
  "#009688",
  "#4caf50",
  "#ff9800",
  "#795548",
  "#607d8b",
  "#ec407a"
];
var CalendarEventsSettingTab = class extends import_obsidian4.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    const t2 = this.plugin.strings();
    containerEl.empty();
    containerEl.createEl("h2", { text: t2.settingsTitle });
    new import_obsidian4.Setting(containerEl).setName(t2.settingsLanguage).setDesc(t2.settingsLanguageDesc).addDropdown((dd) => {
      const cur = this.plugin.currentLocale();
      const autoLabel = cur === "zh" ? "\u81EA\u52A8 (\u8DDF\u968F Obsidian)" : "Auto (follow Obsidian)";
      dd.addOption("auto", autoLabel);
      dd.addOption("en", "English");
      dd.addOption("zh", "\u4E2D\u6587");
      dd.setValue(this.plugin.settings.locale);
      dd.onChange(async (v) => {
        this.plugin.settings.locale = v;
        await this.plugin.saveData(this.plugin.settings);
        this.display();
      });
    });
    new import_obsidian4.Setting(containerEl).setName(t2.settingsStartMon).setDesc(t2.settingsStartMonDesc).addToggle(
      (tg) => tg.setValue(this.plugin.settings.startWeekOnMonday).onChange(async (v) => {
        this.plugin.settings.startWeekOnMonday = v;
        await this.plugin.saveData(this.plugin.settings);
      })
    );
    new import_obsidian4.Setting(containerEl).setName("Show week numbers").setDesc("Display ISO week numbers on the left column.").addToggle(
      (tg) => tg.setValue(this.plugin.settings.showWeekNumbers).onChange(async (v) => {
        this.plugin.settings.showWeekNumbers = v;
        await this.plugin.saveData(this.plugin.settings);
      })
    );
    containerEl.createEl("h3", { text: t2.settingsCategoriesHeading });
    containerEl.createEl("p", {
      text: t2.settingsCategoriesHint,
      cls: "setting-item-description"
    });
    const list = containerEl.createDiv({ cls: "cev-cat-list" });
    const cats = this.plugin.storage.getCategories();
    cats.forEach((cat, idx) => this.renderCategoryRow(list, cat, idx));
    new import_obsidian4.Setting(containerEl).setName(t2.settingsAddCategory).addButton(
      (btn) => btn.setButtonText(t2.settingsAdd).onClick(() => {
        const next = {
          id: makeId("cat"),
          label: "New category",
          color: PRESET_COLORS[Math.floor(Math.random() * PRESET_COLORS.length)]
        };
        const updated = [...this.plugin.storage.getCategories(), next];
        this.plugin.storage.setCategories(updated);
        this.display();
      })
    );
    containerEl.createEl("h3", { text: "Color presets" });
    const presets = containerEl.createDiv({ cls: "cev-presets" });
    for (const c of PRESET_COLORS) {
      const swatch = presets.createDiv({ cls: "cev-preset-swatch" });
      swatch.style.backgroundColor = c;
      swatch.title = c;
    }
    containerEl.createEl("h3", { text: "Data" });
    new import_obsidian4.Setting(containerEl).setName(t2.settingsExport).setDesc(t2.settingsExportDesc).addButton(
      (btn) => btn.setButtonText(t2.settingsCopy).onClick(async () => {
        const json = JSON.stringify(this.plugin.storage.getAll(), null, 2);
        await navigator.clipboard.writeText(json);
        new import_obsidian4.Notice(t2.settingsCopied);
      })
    );
    let importText = "";
    new import_obsidian4.Setting(containerEl).setName(t2.settingsImport).setDesc(t2.settingsImportDesc).addTextArea((ta) => {
      ta.setPlaceholder("{ ... }");
      ta.onChange((v) => importText = v);
      ta.inputEl.rows = 6;
      ta.inputEl.cols = 40;
    }).addButton(
      (btn) => btn.setButtonText(t2.settingsReplace).setWarning().onClick(() => {
        try {
          const parsed = JSON.parse(importText);
          if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.categories)) {
            throw new Error("missing categories array");
          }
          this.plugin.storage.setAll(parsed);
          new import_obsidian4.Notice(
            t2.settingsImported
          );
          window.dispatchEvent(new CustomEvent("calendar-events:updated"));
        } catch (e) {
          new import_obsidian4.Notice(
            t2.settingsImportFailed(e.message)
          );
        }
      })
    );
  }
  renderCategoryRow(container, cat, idx) {
    const row = container.createDiv({ cls: "cev-cat-row" });
    const colorPicker = row.createEl("input", { type: "color", cls: "cev-color-picker" });
    colorPicker.value = cat.color;
    colorPicker.addEventListener("input", () => {
      cat.color = colorPicker.value;
      this.persistCats();
    });
    const labelInput = row.createEl("input", { type: "text", cls: "cev-cat-label" });
    labelInput.value = cat.label;
    labelInput.addEventListener("input", () => {
      cat.label = labelInput.value;
      this.persistCats();
    });
    const idLabel = row.createEl("span", { cls: "cev-cat-id", text: cat.id });
    idLabel.title = "Internal id; safe to rename label, but the id stays the same for existing events.";
    const removeBtn = row.createEl("button", { text: this.plugin.strings().remove, cls: "cev-btn-warn" });
    removeBtn.addEventListener("click", () => {
      const updated = this.plugin.storage.getCategories().filter((_, i) => i !== idx);
      this.plugin.storage.setCategories(updated);
      this.display();
    });
    const presetsRow = row.createDiv({ cls: "cev-cat-presets" });
    for (const c of PRESET_COLORS) {
      const sw = presetsRow.createDiv({ cls: "cev-preset-swatch" });
      sw.style.backgroundColor = c;
      sw.title = c;
      sw.addEventListener("click", () => {
        cat.color = c;
        colorPicker.value = c;
        this.persistCats();
      });
    }
  }
  persistCats() {
    this.plugin.storage.setCategories(this.plugin.storage.getCategories().slice());
  }
};

// src/i18n/strings.ts
var en = {
  viewTitle: "Calendar Events",
  monthPrev: "\u25C0",
  monthNext: "\u25B6",
  monthToday: "Today",
  weekdays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  weekdaysStartMon: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  legend: "Categories: ",
  ribbonTooltip: "Open Calendar",
  modalTitlePrefix: "Events on ",
  eventCount: (n) => `${n} event(s)`,
  checklistCount: (open, total) => `${open}/${total} open task(s)`,
  eventsHeading: "Events",
  checklistHeading: "Checklist",
  addEventLabel: "Add an event",
  addEventButton: "New event",
  addChecklistLabel: "Add a task",
  addChecklistButton: "Add",
  addChecklistPlaceholder: "e.g. Reply to client email",
  title: "Title",
  note: "Note (optional)",
  time: "Time",
  remove: "Remove",
  clearDay: "Clear day",
  cancel: "Cancel",
  save: "Save",
  noEvents: "No events yet.",
  noChecklist: "No tasks yet.",
  savedNotice: (e, t2, d) => `Saved ${e} event(s) and ${t2} task(s) for ${d}.`,
  confirmClear: "Remove all events and checklist items for this day?",
  settingsTitle: "Calendar Events",
  settingsLanguage: "Language",
  settingsLanguageDesc: `Choose how the plugin's UI text appears. "Auto" follows Obsidian's display language.`,
  settingsStartMon: "Start week on Monday",
  settingsStartMonDesc: "When enabled, the weekday header begins with Monday.",
  settingsShowWeekNumbers: "Show week numbers",
  settingsShowWeekNumbersDesc: "Display ISO week numbers on the left column.",
  settingsCategoriesHeading: "Event categories",
  settingsCategoriesHint: "Events are color-coded by category. Add or remove categories here.",
  settingsAddCategory: "Add a category",
  settingsAdd: "Add",
  settingsExport: "Export JSON",
  settingsExportDesc: "Copy the raw calendar-data.json content to your clipboard.",
  settingsCopy: "Copy",
  settingsCopied: "Data copied to clipboard.",
  settingsImport: "Import JSON",
  settingsImportDesc: "Paste calendar-data.json content to replace local data.",
  settingsReplace: "Replace",
  settingsImported: "Calendar data replaced.",
  settingsImportFailed: (e) => `Import failed: ${e}`,
  settingsRemoveConfirm: "Remove this category? Existing events keep the id.",
  notesHeading: "Linked notes",
  notesSearchLabel: "Link a note",
  notesSearchDesc: "Pick a vault file to associate with this day.",
  notesSearchPlaceholder: "Search vault notes\u2026",
  notesAddByUrl: "Add URL\u2026",
  notesUrlPrompt: "External link URL:",
  invalidUrl: "Please enter a valid http(s) URL.",
  openNote: "Open note",
  openExternal: "Open link in browser",
  noNotes: "No linked notes yet."
};
var zh = {
  viewTitle: "\u65E5\u5386\u4E8B\u4EF6",
  monthPrev: "\u25C0",
  monthNext: "\u25B6",
  monthToday: "\u4ECA\u5929",
  weekdays: ["\u65E5", "\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D"],
  weekdaysStartMon: ["\u4E00", "\u4E8C", "\u4E09", "\u56DB", "\u4E94", "\u516D", "\u65E5"],
  legend: "\u7C7B\u522B\uFF1A",
  ribbonTooltip: "\u6253\u5F00\u65E5\u5386",
  modalTitlePrefix: "\u4E8B\u4EF6\uFF1A",
  eventCount: (n) => `${n} \u4E2A\u4E8B\u4EF6`,
  checklistCount: (open, total) => `${open}/${total} \u4E2A\u5F85\u529E`,
  eventsHeading: "\u4E8B\u4EF6",
  checklistHeading: "\u6E05\u5355",
  addEventLabel: "\u6DFB\u52A0\u4E8B\u4EF6",
  addEventButton: "\u65B0\u5EFA\u4E8B\u4EF6",
  addChecklistLabel: "\u6DFB\u52A0\u4EFB\u52A1",
  addChecklistButton: "\u6DFB\u52A0",
  addChecklistPlaceholder: "\u4F8B\u5982\uFF1A\u56DE\u590D\u5BA2\u6237\u90AE\u4EF6",
  title: "\u6807\u9898",
  note: "\u5907\u6CE8\uFF08\u53EF\u9009\uFF09",
  time: "\u65F6\u95F4",
  remove: "\u5220\u9664",
  clearDay: "\u6E05\u7A7A\u5F53\u5929",
  cancel: "\u53D6\u6D88",
  save: "\u4FDD\u5B58",
  noEvents: "\u6682\u65E0\u4E8B\u4EF6\u3002",
  noChecklist: "\u6682\u65E0\u4EFB\u52A1\u3002",
  savedNotice: (e, t2, d) => `\u5DF2\u4FDD\u5B58 ${d} \u7684 ${e} \u4E2A\u4E8B\u4EF6\u4E0E ${t2} \u9879\u4EFB\u52A1\u3002`,
  confirmClear: "\u786E\u8BA4\u6E05\u7A7A\u5F53\u5929\u6240\u6709\u4E8B\u4EF6\u548C\u4EFB\u52A1\uFF1F",
  settingsTitle: "\u65E5\u5386\u4E8B\u4EF6",
  settingsLanguage: "\u8BED\u8A00",
  settingsLanguageDesc: '\u9009\u62E9\u63D2\u4EF6\u754C\u9762\u8BED\u8A00\u3002"\u81EA\u52A8" \u4F1A\u8DDF\u968F Obsidian \u7684\u663E\u793A\u8BED\u8A00\u3002',
  settingsStartMon: "\u4EE5\u5468\u4E00\u5F00\u59CB",
  settingsStartMonDesc: "\u542F\u7528\u540E\uFF0C\u661F\u671F\u7684\u6807\u9898\u4ECE\u5468\u4E00\u5F00\u59CB\u3002",
  settingsShowWeekNumbers: "\u663E\u793A\u5468\u6570",
  settingsShowWeekNumbersDesc: "\u5728\u5DE6\u5217\u663E\u793A ISO \u5468\u6570\u3002",
  settingsCategoriesHeading: "\u4E8B\u4EF6\u7C7B\u522B",
  settingsCategoriesHint: "\u4E8B\u4EF6\u6309\u7C7B\u522B\u7740\u8272\uFF0C\u53EF\u5728\u8FD9\u91CC\u65B0\u589E / \u4FEE\u6539 / \u5220\u9664\u3002",
  settingsAddCategory: "\u65B0\u589E\u7C7B\u522B",
  settingsAdd: "\u6DFB\u52A0",
  settingsExport: "\u5BFC\u51FA JSON",
  settingsExportDesc: "\u590D\u5236\u5F53\u524D calendar-data.json \u7684\u5185\u5BB9\u5230\u526A\u8D34\u677F\u3002",
  settingsCopy: "\u590D\u5236",
  settingsCopied: "\u5DF2\u590D\u5236\u5230\u526A\u8D34\u677F\u3002",
  settingsImport: "\u5BFC\u5165 JSON",
  settingsImportDesc: "\u7C98\u8D34 calendar-data.json \u5185\u5BB9\u4EE5\u66FF\u6362\u672C\u5730\u6570\u636E\u3002",
  settingsReplace: "\u66FF\u6362",
  settingsImported: "\u65E5\u5386\u6570\u636E\u5DF2\u66FF\u6362\u3002",
  settingsImportFailed: (e) => `\u5BFC\u5165\u5931\u8D25\uFF1A${e}`,
  settingsRemoveConfirm: "\u786E\u8BA4\u5220\u9664\u8BE5\u7C7B\u522B\uFF1F\u5DF2\u6709\u4E8B\u4EF6\u4F1A\u4FDD\u7559\u8BE5 id\u3002",
  notesHeading: "\u5173\u8054\u7B14\u8BB0",
  notesSearchLabel: "\u5173\u8054\u7B14\u8BB0",
  notesSearchDesc: "\u9009\u62E9\u4E00\u4E2A vault \u5185\u7684\u7B14\u8BB0\uFF0C\u628A\u5B83\u4E0E\u8FD9\u4E00\u5929\u5173\u8054\u8D77\u6765\u3002",
  notesSearchPlaceholder: "\u641C\u7D22 vault \u7B14\u8BB0\u2026",
  notesAddByUrl: "\u6DFB\u52A0\u5916\u94FE\u2026",
  notesUrlPrompt: "\u5916\u90E8\u94FE\u63A5\u5730\u5740\uFF1A",
  invalidUrl: "\u8BF7\u8F93\u5165\u5408\u6CD5\u7684 http(s) \u94FE\u63A5\u3002",
  openNote: "\u6253\u5F00\u7B14\u8BB0",
  openExternal: "\u5728\u6D4F\u89C8\u5668\u4E2D\u6253\u5F00",
  noNotes: "\u6682\u65E0\u5173\u8054\u7B14\u8BB0\u3002"
};
var STRINGS = { en, zh };
function resolveLocale(setting, obsidianLocale) {
  if (setting === "en" || setting === "zh")
    return setting;
  const lower = (obsidianLocale ?? "").toLowerCase();
  if (lower.startsWith("zh"))
    return "zh";
  return "en";
}
function t(setting, obsidianLocale) {
  return STRINGS[resolveLocale(setting, obsidianLocale)];
}

// src/main.ts
var DEFAULT_SETTINGS = {
  showWeekNumbers: false,
  startWeekOnMonday: false,
  locale: "auto"
};
var CalendarEventsPlugin = class extends import_obsidian5.Plugin {
  constructor() {
    super(...arguments);
    this.settings = DEFAULT_SETTINGS;
  }
  async onload() {
    this.storage = new CalendarStorage(this);
    await this.storage.load();
    this.registerView(
      VIEW_TYPE_CALENDAR,
      (leaf) => this.calendarView = new CalendarView(leaf, this)
    );
    this.addRibbonIcon("calendar-with-checkmark", this.strings().ribbonTooltip, () => void this.activateView());
    this.addCommand({
      id: "open-calendar-view",
      name: "Open Calendar sidebar",
      callback: () => void this.activateView()
    });
    this.addCommand({
      id: "open-day-editor",
      name: "Edit today's events",
      callback: () => {
        new DayEditorModal(this.app, this, this.todayKey()).open();
      }
    });
    this.addCommand({
      id: "jump-to-today",
      name: "Jump sidebar calendar to today",
      callback: async () => {
        await this.activateView();
        this.calendarView?.focusDate(this.todayKey());
      }
    });
    window.addEventListener("calendar-events:updated", () => {
      this.calendarView?.requestRender();
    });
    this.addSettingTab(new CalendarEventsSettingTab(this.app, this));
  }
  onunload() {
  }
  async activateView() {
    const { workspace } = this.app;
    const existing = workspace.getLeavesOfType(VIEW_TYPE_CALENDAR);
    if (existing.length > 0) {
      workspace.revealLeaf(existing[0]);
      return;
    }
    const leaf = workspace.getRightLeaf(false);
    if (!leaf) {
      new import_obsidian5.Notice("Could not open the right sidebar.");
      return;
    }
    await leaf.setViewState({ type: VIEW_TYPE_CALENDAR, active: true });
    workspace.revealLeaf(leaf);
  }
  todayKey() {
    return this.formatDateKey(/* @__PURE__ */ new Date());
  }
  formatDateKey(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  getCategory(id) {
    return this.storage.getCategories().find((c) => c.id === id);
  }
  /** Best-effort: read the language used elsewhere in the vault. */
  detectBrowserLocale() {
    try {
      if (typeof navigator !== "undefined" && navigator.language) {
        return navigator.language;
      }
    } catch (_) {
    }
    return "";
  }
  strings() {
    return t(this.settings.locale, this.detectBrowserLocale());
  }
  currentLocale() {
    return resolveLocale(this.settings.locale, this.detectBrowserLocale());
  }
};
